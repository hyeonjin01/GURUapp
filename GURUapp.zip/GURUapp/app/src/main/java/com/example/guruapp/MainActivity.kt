package com.example.guruapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.guruapp.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity() {

    var selectedDate: Date? = null


    lateinit var EdtSchedulName : EditText
    lateinit var Color : Button
    lateinit var BtnColorSelect : Button
    lateinit var BtnDate : Button
    lateinit var SpinnerStartHour : Spinner
    lateinit var SpinnerStartMinute : Spinner
    lateinit var SpinnerEndHour : Spinner
    lateinit var SpinnerEndMinute : Spinner
    lateinit var EdtPlace : EditText
    lateinit var EdtMemo : EditText
    lateinit var BtnInsert : Button

    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root



        EdtSchedulName = findViewById(R.id.EdtScheduleName)
        Color = findViewById(R.id.Color)
        BtnColorSelect = findViewById(R.id.BtnColorSelect)
        BtnDate = findViewById(R.id.BtnDate)
        SpinnerStartHour = findViewById(R.id.SpinnerStartHour)
        SpinnerStartMinute = findViewById(R.id.SpinnerStartMinute)
        SpinnerEndHour = findViewById(R.id.SpinnerEndHour)
        SpinnerEndMinute = findViewById(R.id.SpinnerEndMinute)
        EdtPlace = findViewById(R.id.EdtPlace)
        EdtMemo = findViewById(R.id.EdtMemo)
        BtnInsert = findViewById(R.id.BtnInsert)


        BtnColorSelect.setOnClickListener {

        }

        BtnDate.setOnClickListener {
            val today = GregorianCalendar()
            val year: Int = today.get(Calendar.YEAR)
            val month: Int = today.get(Calendar.MONTH)
            val date: Int = today.get(Calendar.DATE)

            val dlg = DatePickerDialog(this, object : DatePickerDialog.OnDateSetListener {
                override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
                    BtnDate.setText("${year}년 ${month + 1}월 ${dayOfMonth}일")
                }
            }, year, month, date)
            dlg.show()
        }

        val Adapter1 = ArrayAdapter.createFromResource(
            this,
            R.array.hour_list,
            android.R.layout.simple_spinner_dropdown_item
        )
        val Adapter2 = ArrayAdapter.createFromResource(
            this,
            R.array.minute_list,
            android.R.layout.simple_spinner_dropdown_item
        )

        SpinnerStartHour.setAdapter(Adapter1)
        SpinnerStartMinute.setAdapter(Adapter2)
        SpinnerEndHour.setAdapter(Adapter1)
        SpinnerEndMinute.setAdapter(Adapter2)

    }
}
